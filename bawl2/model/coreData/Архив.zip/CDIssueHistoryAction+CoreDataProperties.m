//
//  CDIssueHistoryAction+CoreDataProperties.m
//  bawl2
//
//  Created by Admin on 02.04.16.
//  Copyright © 2016 Admin. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "CDIssueHistoryAction+CoreDataProperties.h"

@implementation CDIssueHistoryAction (CoreDataProperties)

@dynamic action;
@dynamic actionNumber;
@dynamic stringDate;
@dynamic userID;
@dynamic issue;

@end
